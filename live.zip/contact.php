<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars($_POST['name']); // Naam
    $email = htmlspecialchars($_POST['email']); // Email
    $message = htmlspecialchars($_POST['message']); // Message

    $to = "aapka-email@example.com"; // Yaha apna email daalein
    $subject = "Nayi Message Contact Form Se";
    $body = "Naam: $name\nEmail: $email\nMessage:\n$message";

    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";

    if (mail($to, $subject, $body, $headers)) {
        echo "Aapka message safalta se bhej diya gaya hai!";
    } else {
        echo "Message bhejne mein samasya hui.";
    }
}
?>
